package com.mycareerai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CareerApp() }
    }
}

@Composable
fun CareerApp() {
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("") }
    var experience by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text("My Career AI", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text("Build your next career move with confidence.")
                HorizontalDivider()
                Text("Create your CV", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full name") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Target job title") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = experience, onValueChange = { experience = it }, label = { Text("Experience and skills") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                Button(
                    onClick = {
                        result = "CV profile\nName: $name\nTarget role: $role\nExperience: $experience\n\nNext step: connect the secure AI service to generate a polished CV."
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Create my CV") }
                if (result.isNotBlank()) {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(result, modifier = Modifier.padding(16.dp))
                    }
                }
                Text("More tools coming soon: Job Matching • Cover Letter Generator", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
